<!DOCTYPE html>
<html>
<head>
    <title>Dynamic Table</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th a {
            color: black;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <h1>Dynamic Table</h1>
    <table>
        <thead>
            <tr>
                <th><a href="{{ route('data.index', ['sort' => 'id', 'direction' => request('direction') === 'asc' ? 'desc' : 'asc', 'page' => request('page')]) }}">ID</a></th>
                <th><a href="{{ route('data.index', ['sort' => 'name', 'direction' => request('direction') === 'asc' ? 'desc' : 'asc', 'page' => request('page')]) }}">Name</a></th>
                <th><a href="{{ route('data.index', ['sort' => 'email', 'direction' => request('direction') === 'asc' ? 'desc' : 'asc', 'page' => request('page')]) }}">Email</a></th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data as $item)
                <tr>
                    <td>{{ $item['id'] }}</td>
                    <td>{{ $item['name'] }}</td>
                    <td>{{ $item['email'] }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <div>
        @for ($i = 1; $i <= $totalPages; $i++)
            <a href="{{ route('data.index', ['sort' => request('sort'), 'direction' => request('direction'), 'page' => $i]) }}">{{ $i }}</a>
        @endfor
    </div>
</body>
</html>
