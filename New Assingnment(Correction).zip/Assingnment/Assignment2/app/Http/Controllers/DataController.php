namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;

class DataController extends Controller
{
    public function index(Request $request)
    {
        $json = file_get_contents(public_path('assets/data.json'));
        $data = collect(json_decode($json, true));

        // Sorting
        if ($request->has('sort') && $request->has('direction')) {
            $data = $data->sortBy([
                [$request->input('sort'), $request->input('direction')]
            ]);
        }

        // Pagination
        $perPage = 5;
        $page = $request->input('page', 1);
        $pagedData = $data->slice(($page - 1) * $perPage, $perPage)->values();

        return view('data.index', [
            'data' => $pagedData,
            'page' => $page,
            'totalPages' => ceil($data->count() / $perPage),
            'sort' => $request->input('sort'),
            'direction' => $request->input('direction')
        ]);
    }
}
