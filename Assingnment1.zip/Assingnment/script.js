// table data
const tableData = [
    { id: 1, name: 'John Doe', age: 25 },
    { id: 2, name: 'Jane Doe', age: 30 },
    { id: 3, name: 'Bob Smith', age: 35 },
    { id: 4, name: 'Alice Johnson', age: 20 },
    { id: 5, name: 'Mike Brown', age: 40 },
    { id: 6, name: 'Emily Davis', age: 28 },
    { id: 7, name: 'Tom Harris', age: 32 },
    { id: 8, name: 'Sarah Lee', age: 24 },
    { id: 9, name: 'Kevin White', age: 36 },
    { id: 10, name: 'Lisa Martin', age: 29 },
    // add more data here...
];

// table view
const tableView = document.getElementById('table-view');
const tableBody = document.getElementById('table-body');
const pagination = document.getElementById('pagination');
const prevPageBtn = document.getElementById('prev-page');
const nextPageBtn = document.getElementById('next-page');
const pageNumSpan = document.getElementById('page-num');

let currentPage = 1;
let rowsPerPage = 5;

function renderTable() {
    tableBody.innerHTML = '';
    const startIndex = (currentPage - 1) * rowsPerPage;
    const endIndex = startIndex + rowsPerPage;
    const currentPageData = tableData.slice(startIndex, endIndex);
    currentPageData.forEach((rowData) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${rowData.id}</td>
            <td>${rowData.name}</td>
            <td>${rowData.age}</td>
        `;
        tableBody.appendChild(row);
    });
}

function sortTable(column) {
    tableData.sort((a, b) => {
        if (a[column] < b[column]) return -1;
        if (a[column] > b[column]) return 1;
        if (a[column] < b[column]) return -1;
        if (a[column] > b[column]) return 1;
        return 0;
    });
    renderTable();
}

prevPageBtn.addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        renderTable();
        pageNumSpan.textContent = currentPage;
    }
});

nextPageBtn.addEventListener('click', () => {
    if (currentPage < Math.ceil(tableData.length / rowsPerPage)) {
        currentPage++;
        renderTable();
        pageNumSpan.textContent = currentPage;
    }
});

// infinite slider
const slider = document.getElementById('slider');
const sliderContent = document.getElementById('slider-content');
const prevSlideBtn = document.getElementById('prev-slide');
const nextSlideBtn = document.getElementById('next-slide');

let slideIndex = 0;
let slideWidth = 200; // adjust this value to match your slider content width

function renderSlider() {
    sliderContent.innerHTML = '';
    for (let i = 0; i < 5; i++) { // render 5 slides at a time
        const slide = document.createElement('div');
        slide.textContent = `Slide ${slideIndex + i + 1}`;
        sliderContent.appendChild(slide);
    }
}

function slideTo(index) {
    slideIndex = index;
    renderSlider();
    sliderContent.style.transform = `translateX(${index * -slideWidth}px)`;
}

prevSlideBtn.addEventListener('click', () => {
    slideTo(slideIndex - 1);
});

nextSlideBtn.addEventListener('click', () => {
    slideTo(slideIndex + 1);
});

// initialize table view and slider
renderTable();
renderSlider();