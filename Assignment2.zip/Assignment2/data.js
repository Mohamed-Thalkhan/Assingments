export class Data {
    constructor() {
      this.data = [];
      this.currentPage = 1;
      this.pageSize = 10;
      this.sortColumn = '';
      this.sortOrder = '';
    }
  
    async fetchData() {
      const response = await fetch('/assets/data.json');
      const jsonData = await response.json();
      this.data = jsonData;
    }
  
    getPageData() {
      const startIndex = (this.currentPage - 1) * this.pageSize;
      const endIndex = startIndex + this.pageSize;
      return this.data.slice(startIndex, endIndex);
    }
  
    sortData(column) {
      if (this.sortColumn === column) {
        this.sortOrder = this.sortOrder === 'asc'? 'desc' : 'asc';
      } else {
        this.sortColumn = column;
        this.sortOrder = 'asc';
      }
      this.data.sort((a, b) => {
        if (a[column] < b[column]) {
          return this.sortOrder === 'asc'? -1 : 1;
        } else if (a[column] > b[column]) {
          return this.sortOrder === 'asc'? 1 : -1;
        } else {
          return 0;
        }
      });
    }
  }