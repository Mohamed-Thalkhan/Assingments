import { Controller } from './controller';

const controller = new Controller();

document.addEventListener('DOMContentLoaded', async () => {
  await controller.init();
  renderTable();
  addEventListeners();
});

function renderTable() {
  const tableBody = document.getElementById('table-body');
  const pageData = controller.getPageData();
  tableBody.innerHTML = '';
  pageData.forEach((row) => {
    const tableRow = document.createElement('tr');
    tableRow.innerHTML = `
      <td>${row.name}</td>
      <td>${row.age}</td>
      <td>${row.city}</td>
    `;
    tableBody.appendChild(tableRow);
  });
  updatePagination();
}

function addEventListeners() {
  document.querySelectorAll('th a').forEach((element) => {
    element.addEventListener('click', (event) => {
      const column = event.target.getAttribute('data-sort');
      controller.sortData(column);
      renderTable();
      updateUrlParams();
    });
  });

  document.getElementById('prev-page').addEventListener('click', () => {
    controller.setPage(controller.data.currentPage - 1);
    renderTable();
    updateUrlParams();
  });

  document.getElementById('next-page').addEventListener('click', () => {
    controller.setPage(controller.data.currentPage + 1);
    renderTable();
    updateUrlParams();
  });
}

function updatePagination() {
  const pageInfo = document.getElementById('page-info');
  pageInfo.textContent = `Page ${controller.data.currentPage} of ${Math.ceil(controller.data.data.length / controller.data.pageSize)}`;
  const prevPageButton = document.getElementById('prev-page');
  prevPageButton.disabled = controller.data.currentPage === 1;
  const nextPageButton = document.getElementById('next-page');
  nextPageButton.disabled = controller.data.currentPage === Math.ceil(controller.data.data.length / controller.data.pageSize);
}

function updateUrlParams() {
  const sortParams = controller.getSortParams();
  const pageParams = controller.getPageParams();
  const urlParams = `${sortParams}&${pageParams}`;
  const url = `?${urlParams}`;
  window.history.pushState({}, '', url);
}

window.addEventListener('popstate', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const sortColumn = urlParams.get('sort');
  const sortOrder = urlParams.get('order');
  const page = parseInt(urlParams.get('page'), 10);
  if (sortColumn) {
    controller.data.sortColumn = sortColumn;
    controller.data.sortOrder = sortOrder;
  }
  if (page) {
    controller.data.currentPage = page;
  }
  renderTable();
});