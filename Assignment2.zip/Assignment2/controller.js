import { Data } from './data';

export class Controller {
  constructor() {
    this.data = new Data();
  }

  async init() {
    await this.data.fetchData();
  }

  getPageData() {
    return this.data.getPageData();
  }

  sortData(column) {
    this.data.sortData(column);
  }

  setPage(page) {
    this.data.currentPage = page;
  }

  getSortParams() {
    return `sort=${this.data.sortColumn}&order=${this.data.sortOrder}`;
  }

  getPageParams() {
    return `page=${this.data.currentPage}`;
  }
}